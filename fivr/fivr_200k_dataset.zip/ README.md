#  FIVR-200K dataset
A dataset that simulates the problem of Fine-grained Incident Video Retrieval (FIVR).

For more details, see the FIVR paper:
https://arxiv.org/abs/1809.04094
